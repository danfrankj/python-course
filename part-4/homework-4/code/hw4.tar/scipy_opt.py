import scipy.optimize



def test_opt():
    # use scipy.optimize to minimize the function 
    # .5 * x^T * A * x - b^T * x 
    return np.array([])

def verify_opt(A, b, x_star):
    # verify that A * x_star = b
    return True
